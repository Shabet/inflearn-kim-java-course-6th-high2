package network.tcp.autocloseable;

public class CallException extends Exception {

    public CallException(String message) {
        super(message);
    }
}
