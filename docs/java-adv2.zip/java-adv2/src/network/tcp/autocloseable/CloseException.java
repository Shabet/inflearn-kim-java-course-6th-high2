package network.tcp.autocloseable;

public class CloseException extends Exception {

    public CloseException(String message) {
        super(message);
    }
}
