package annotation.basic.inherited;

public class Child extends Parent {
}
