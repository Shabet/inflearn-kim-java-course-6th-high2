package annotation.basic.inherited;

@InheritedAnnotation
@NoInheritedAnnotation
public class Parent {
}
