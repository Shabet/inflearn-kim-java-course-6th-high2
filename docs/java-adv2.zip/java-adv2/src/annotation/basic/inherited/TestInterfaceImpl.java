package annotation.basic.inherited;

public class TestInterfaceImpl implements TestInterface {
}
