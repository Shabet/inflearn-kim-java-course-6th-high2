package annotation.basic;

@AnnoElement("data")
public class ElementData3 {
}
