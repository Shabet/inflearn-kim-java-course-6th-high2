package annotation.basic;

@AnnoElement(value = "data", tags = "t1")
public class ElementData2 {
}
