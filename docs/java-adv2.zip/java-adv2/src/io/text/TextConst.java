package io.text;

public class TextConst {
    public static final String FILE_NAME = "temp/hello.txt";
}
